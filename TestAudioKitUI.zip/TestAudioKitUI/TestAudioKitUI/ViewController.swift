//
//  ViewController.swift
//  TestAudioKitUI
//
//  Created by Cosmin Vlaicu on 31/03/2020.
//  Copyright © 2020 Cosmin Vlaicu. All rights reserved.
//

import UIKit
import AudioKit
import AudioKitUI

class ViewController: UIViewController {
    var oscillator = AKOscillator()
    var oscillator2 = AKOscillator()
    
    var mic: AKMicrophone!
    var fftTap: AKFFTTap?
    var timer:  Timer!
    let FFT_SIZE = 512
    let sampleRate:double_t = 44100

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        AudioKit.output = AKMixer(oscillator, oscillator2)
        do {
            try AudioKit.start()
        }catch{
            print("Unexpected error: \(error).")
        }
        
        oscillator.amplitude = random(0.9, 1)
        oscillator.frequency = random(14000, 14500)
        do{
            sleep(3)
        }
        oscillator.start()
        do{
            sleep(3)
        }
        oscillator.stop()
        
        oscillator.amplitude = random(0.9, 1)
        oscillator.frequency = random(10000, 10500)
        
        do{
            sleep(1)
        }
        
//        oscillator.start()
//
//        do{
//            sleep(3)
//        }
//        oscillator.stop()
//        do{
//            sleep(3)
//        }
//        AKSettings.sampleRate = 48000
        AKSettings.sampleRate = AudioKit.engine.inputNode.inputFormat(forBus: 0).sampleRate
        
        print(AKSettings.sampleRate)
        mic = AKMicrophone()
//        fftTap = AKFFTTap.init(mic)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

//        do {
//            try AudioKit.start()
//        } catch {
//            AKLog("AudioKit did not start!")
//        }

//        mic.start()

//        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (timer) in
//
//            for i in 0...510 {
//
//                let re = self.fftTap!.fftData[i]
//                let im = self.fftTap!.fftData[i + 1]
//                let normBinMag = 2.0 * sqrt(re * re + im * im)/self.FFT_SIZE
//                let amplitude = (20.0 * log10(normBinMag))
//
//                print("bin: \(i/2) \t ampl.: \(amplitude)")
//            }
//
//
//        })
    }
    



}

